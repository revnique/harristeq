define([
	"../search/SearchModel.js"
],
function (SearchModel) {
    "use strict";
    var SearchView;
    SearchView = (function () {

        var typeAheadCharLength = 3;

        SearchView.prototype.model = SearchModel;

        SearchModel.results.initialize();
        function SearchView() {
            this.$el = $("#trailSearch");
            SearchModel.results.initialize();

            var submitFunc = function (event) {
                event.preventDefault();
                var q = $(event.currentTarget).find('input[name="search-input"]').val();
                location.href = "http://harristeq.com/home/test.htm/search?searchTerm=" + encodeURIComponent(q);
            };

            $('#trailSearch form').submit(submitFunc);
            $('.search-tablet form').submit(submitFunc);
            
            this.$el.find("#search-input").typeahead({
                minLength: typeAheadCharLength
            }, {
                name: "results",
                displayKey: "value",
                source: SearchModel.results.ttAdapter()
            }).on('typeahead:selected', function(obj, datum) {
                location.href = datum.url;
            });

            $("#search-tablet-input").typeahead({
                minLength: typeAheadCharLength
            }, {
                name: "results",
                displayKey: "value",
                source: SearchModel.results.ttAdapter()
            }).on('typeahead:selected', function(obj, datum) {
                location.href = datum.url;
            });
        }
        
        return SearchView;

    })();
    return SearchView;
});
