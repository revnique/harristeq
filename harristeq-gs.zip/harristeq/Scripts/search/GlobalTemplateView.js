define([
	"../search/SearchView.js"
], 
function(
	SearchView
) {
	var ready;
	return ready = function () {
	        new SearchView();
	};
});
