define(["bloodhound"], function (Bloodhound) {
    "use strict";

    var SearchModel;
    SearchModel = (function () {

        SearchModel.prototype.results = null;
        SearchModel.prototype.data = null;

        function SearchModel() {
            this.results = new Bloodhound({
                datumTokenizer: Bloodhound.tokenizers.obj.whitespace("value"),
                queryTokenizer: Bloodhound.tokenizers.whitespace,
                prefetch: '../scripts/home/dorbaSampleData.json'
                //remote: {
                //    ajax: {
                //        type: 'POST',
                //        contentType: "application/x-www-form-urlencoded;"
                //    },
                //    url: 'http://harristeq.com/home/test.htm/typeahead?searchTerm=%QUERY',
                //    filter: function (results) {
                //        return $.map(results, function (result) {
                //                return {
                //                    value: result,
                //                    url: "http://harristeq.com/home/test.htm/search?searchTerm=" + encodeURIComponent(result)
                //            };
                //        }
				//     );
                //    }
                //}
            });
        }

        return SearchModel;

    })();
    return new SearchModel();

});
