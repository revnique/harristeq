define([
	"../models/SearchModel.js"
],
function (SearchModel) {
    "use strict";
    var SearchView;
    SearchView = (function () {

        var typeAheadCharLength = isNaN(FrameApp.prototype.typeAheadCharLength) == true ? 3 : parseInt(FrameApp.prototype.typeAheadCharLength);

        SearchView.prototype.model = SearchModel;

        function SearchView() {
            this.$el = $("#frameSearch");
            vent.on("App:search:focus", _.bind(this.onSearchFocus, this));
            vent.on("App:search:blur", _.bind(this.onSearchBlur, this));
            SearchModel.results.initialize();

            var submitFunc = function (event) {
                event.preventDefault();
                var q = $(event.currentTarget).find('input[name="q"]').val();
                location.href = (FrameApp.prototype.baseUrl != undefined ? FrameApp.prototype.baseUrl : '') + "/browse/search?searchTerm=" + encodeURIComponent(q);
            };

            $('#frameSearch form').submit(submitFunc);
            $('.search-tablet form').submit(submitFunc);


            this.$el.find("#search-input").typeahead({
                minLength: typeAheadCharLength
            }, {
                name: "results",
                displayKey: "value",
                source: SearchModel.results.ttAdapter()
            }).on('typeahead:selected', function(obj, datum) {
                location.href = datum.url;
            });

            $("#search-tablet-input").typeahead({
                minLength: typeAheadCharLength
            }, {
                name: "results",
                displayKey: "value",
                source: SearchModel.results.ttAdapter()
            }).on('typeahead:selected', function(obj, datum) {
                location.href = datum.url;
            });

            this.initEvents();
        }

        SearchView.prototype.initEvents = function () {
            this.$el.find("input").on("focus", _.bind(this.onFocus, this));
            this.$el.find("input").on("blur", _.bind(this.onFocus, this));
            return this.$el.find(".cancel").on("click", _.bind(this.onCancel, this));
        };

        SearchView.prototype.onSwipeRight = function (event, direction, distance, duration, finger) {
            return vent.trigger("App:search:close");
        };

        SearchView.prototype.onSearchFocus = function () {
            return this.$el.find("#search-input").focus();
        };

        SearchView.prototype.onSearchBlur = function () {
            return this.$el.find("#search-input").blur();
        };

        SearchView.prototype.onFocus = function () {
            this.$el.find(".icon").removeClass("search-light-gray");
            return this.$el.find(".icon").addClass("search-gray");
        };

        SearchView.prototype.onBlur = function () {
            this.$el.find("#search-input").val("");
            this.$el.find(".icon").removeClass("search-gray");
            return this.$el.find(".icon").addClass("search-light-gray");
        };

        SearchView.prototype.onCancel = function () {
            return vent.trigger("App:search:close");
        };

        return SearchView;

    })();
    return SearchView;
});
