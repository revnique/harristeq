define(["bloodhound"], function (Bloodhound) {
    "use strict";

    var SearchModel;
    SearchModel = (function () {

        SearchModel.prototype.results = null;
        SearchModel.prototype.data = null;

        function SearchModel() {
            this.results = new Bloodhound({
                datumTokenizer: Bloodhound.tokenizers.obj.whitespace("value"),
                queryTokenizer: Bloodhound.tokenizers.whitespace,
                remote: {
                    ajax: {
                        type: 'POST',
                        contentType: "application/x-www-form-urlencoded;"
                    },
                    url: (FrameApp.prototype.baseUrl != undefined ? FrameApp.prototype.baseUrl : '') + '/browse/typeahead?searchTerm=%QUERY', // TODO: replace hard coded url something dynamic
                    filter: function (results) {
                        return $.map(results, function (result) {
                                return {
                                    value: result,
                                    url: (FrameApp.prototype.baseUrl != undefined ? FrameApp.prototype.baseUrl : '') + "/browse/search?searchTerm=" + encodeURIComponent(result)
                            };
                        }
				     );
                    }
                }
            });
        }

        return SearchModel;

    })();
    return new SearchModel();

});
